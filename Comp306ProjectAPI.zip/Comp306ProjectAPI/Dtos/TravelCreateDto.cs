﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Comp306ProjectAPI.Dtos
{
    public class TravelCreateDto
    {
        [Required]
        [MaxLength(250)]

        public string destination { get; set; }
        public int budget { get; set; }
    }
}
