﻿using AutoMapper;
using Comp306ProjectAPI.Data;
using Comp306ProjectAPI.Dtos;
using Comp306ProjectAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Comp306ProjectAPI.Controllers
{
    [Route("api/TravelPackage")]
    [ApiController]
    public class TravelController : ControllerBase
    {
        private readonly ITravelRepo _repository;
        private readonly IMapper _mapper;

        public TravelController(ITravelRepo repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        //GET api/commands
        [HttpGet]
        public ActionResult<IEnumerable<TravelReadDto>> GetAllTravels()
        {
            var commandItems = _repository.GetAllTravels();

            return Ok(_mapper.Map<IEnumerable<TravelReadDto>>(commandItems));
        }

        //GET api/commands/{id}
        [HttpGet("{id}", Name = "GetTravelById")]
        public ActionResult<TravelReadDto> GetTravelById(int id)
        {
            var commandItem = _repository.GetTravelById(id);
            if (commandItem != null)
            {
                return Ok(_mapper.Map<TravelReadDto>(commandItem));
            }
            return NotFound();
        }



        //POST api/commands
        [HttpPost]
        public ActionResult<TravelReadDto> CreateTravel(TravelCreateDto commandCreateDto)
        {
            var commandModel = _mapper.Map<Travel>(commandCreateDto);
            _repository.CreateTravel(commandModel);
            _repository.SaveChanges();

            var commandReadDto = _mapper.Map<TravelReadDto>(commandModel);

            return CreatedAtRoute(nameof(GetTravelById), new { Id = commandReadDto.id }, commandReadDto);
        }


        //PUT api/commands/{id}
        [HttpPut("{id}")]
        public ActionResult UpdateTravel(int id, TravelUpdateDto commandUpdateDto)
        {
            var commandModelFromRepo = _repository.GetTravelById(id);
            if (commandModelFromRepo == null)
            {
                return NotFound();
            }
            _mapper.Map(commandUpdateDto, commandModelFromRepo);

            _repository.UpdateTravel(commandModelFromRepo);

            _repository.SaveChanges();

            return NoContent();
        }


        [HttpDelete("{id}")]
        public ActionResult DeleteCommand(int id)
        {
            var commandModelFromRepo = _repository.GetTravelById(id);
            if (commandModelFromRepo == null)
            {
                return NotFound();
            }
            _repository.DeleteTravel(commandModelFromRepo);
            _repository.SaveChanges();

            return NoContent();
        }

    }


}