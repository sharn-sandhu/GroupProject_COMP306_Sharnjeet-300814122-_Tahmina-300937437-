﻿using AutoMapper;
using Comp306ProjectAPI.Dtos;
using Comp306ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Comp306ProjectAPI.Profiles
{
    public class CommandsProfile : Profile
    {
        public CommandsProfile()
        {
            //Source -> Target
            CreateMap<Travel, TravelReadDto>();
            CreateMap<TravelCreateDto, Travel>();
            CreateMap<TravelUpdateDto, Travel>();
            CreateMap<Travel, TravelUpdateDto>();
        }

    }

}