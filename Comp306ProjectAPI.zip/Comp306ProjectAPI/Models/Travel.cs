﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Comp306ProjectAPI.Models
{
    public class Travel
    {

        public int id { get; set; }
        public string destination { get; set; }
        public int budget { get; set; }
    }
}
