﻿using System;
using System.Collections.Generic;
using System.Linq;
using Comp306ProjectAPI.Models;
namespace Comp306ProjectAPI.Data
{
    public class SqlTravelRepo: ITravelRepo
    {

        private readonly TravelContext _context;

        public SqlTravelRepo(TravelContext context)
        {
            _context = context;
        }

        public void CreateTravel(Travel cmd)
        {
            if (cmd == null)
            {
                throw new ArgumentNullException(nameof(cmd));
            }

            _context.Travels.Add(cmd);
        }

        public void DeleteTravel(Travel cmd)
        {
            if (cmd == null)
            {
                throw new ArgumentNullException(nameof(cmd));
            }
            _context.Travels.Remove(cmd);
        }

        public IEnumerable<Travel> GetAllTravels()
        {
            return _context.Travels.ToList();
        }

        public Travel GetTravelById(int id)
        {
            return _context.Travels.FirstOrDefault(p => p.id == id);
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() >= 0;
        }

        public void UpdateTravel(Travel cmd)
        {
            //Nothing
        }




    }
}
