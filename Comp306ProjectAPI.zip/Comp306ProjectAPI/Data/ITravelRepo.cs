﻿using Comp306ProjectAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Comp306ProjectAPI.Data
{
    public interface ITravelRepo
    {

        bool SaveChanges();

        IEnumerable<Travel> GetAllTravels();
        Travel GetTravelById(int id);
        void CreateTravel(Travel cmd);
        void UpdateTravel(Travel cmd);
        void DeleteTravel(Travel cmd);
    }
}