﻿namespace COMP306_Tahmina_Sharnjeet_Project
{
    internal class TravelPackage
    {
    }
}